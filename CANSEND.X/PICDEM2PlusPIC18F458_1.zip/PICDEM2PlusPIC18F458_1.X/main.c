#include "p18F458.h"
void delay();

void delay() {
    int counter = 0;
    for (counter = 0; counter<10000; counter++) {
        ;
    }
}

void main(void) {
    TRISB = 0;

    while (1) {
        PORTB = 0x0F;

        delay();

        PORTB = 0x00;
        
        delay();
    }
}


